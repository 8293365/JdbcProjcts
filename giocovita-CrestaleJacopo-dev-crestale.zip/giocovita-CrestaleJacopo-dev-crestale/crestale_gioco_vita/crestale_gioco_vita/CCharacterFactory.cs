﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crestale_gioco_vita
{
    class CCharacterFactory
    {
        public static CCharacter GetRndCharacter(int x, int y)
        {
            Random rnd = new Random();
            switch (rnd.Next(0, 4))
            {
                default:
                    return new CCarrot(x, y);
                case 0:
                    return new CCarrot(x, y);
                case 1:
                    return new CRabbit(x, y);
                case 2:
                    return new CFox(x, y);
                case 3:
                    return new CLion(x, y);
            }
        }
    }
}
