using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

using crestale_gioco_vita;
namespace crestale_gioco_vita
{
    public partial class MainForm : Form
    {
        public static CField GameField = new CField(true);
        public Thread GameThread; 
        private bool GameRunning = false;
        private WinnerForm WinnerPopup;

        public MainForm()
        {
            MainFormInitialize(CField.SIZE);   //funzione fatta da me in Form1.Designer.cs che crea le celle in base alle dimensioni del campo
        }

        private void TestAddChar(int x, int y)      //funzione per testare il programma, aggiungendo un personaggio manualmente
        {
            GameField.CharMat[x, y] = new CLion(x, y);
        }

        private void LoadImages()      //carica le immagini nelle varie picture box
        {
            for(int i = 0; i < CField.SIZE; i++)
            {
                for (int j = 0; j < CField.SIZE; j++)
                {
                    if (GameField.CharMat[i, j] != null)
                        picBoxMat[i, j].Image = GameField.CharMat[i, j].Img;
                    else
                        picBoxMat[i, j].Image = null;
                }
            }
        }

        private void ClearImages()      //rimuove tutte le immagini (per quando si preme stop)
        {
            for (int i = 0; i < CField.SIZE; i++)
                for (int j = 0; j < CField.SIZE; j++)
                        picBoxMat[i, j].Image = null;
        }

        private void checkIfDead(int x, int y)  //verifica se un personaggio in una data posizione � morto
        {
            //se � morto viene rimosso dalla lista, dalla matrice di personaggi e viene tolta l'immagine
            if (GameField.CharMat[x, y].HP <= 0)    
            {
                GameField.CharList.Remove(GameField.CharMat[x, y]); 
                GameField.CharMat[x, y] = null;
                picBoxMat[x, y].Image = null;
            }
        }

        private void MoveCharacter(CCharacter character)    //gestisce il movimento di ogni personaggio
        {
            if (GameField.CharList.Count == 1)
            {
                GameRunning = false;
                WinnerPopup = new WinnerForm();
                WinnerPopup.winnerPicBox.Image = GameField.CharList[0].Img;
                WinnerPopup.ShowDialog();
                return; 
            }

            (int, int) ?nextCell = character.SearchMove();

            int curr_x = character.Coord.x;     //per la pulizia del codice
            int curr_y = character.Coord.y;

            CCharacter currCell = character;

            if(GameField.CharMat[curr_x, curr_y] is CCarrot)        //gestione delle carote
            {
                GameField.CharMat[curr_x, curr_y].HP -= 15;
                checkIfDead(curr_x, curr_y);
            }

            if (nextCell == null) return;       //non ci sono celle dove muoversi

            int next_x = nextCell.Value.Item1;      //per la pulizia del codice
            int next_y = nextCell.Value.Item2;

            if (GameField.CharMat[next_x, next_y] != null)      //il personaggio che si sta muovendo mangia
            {
                GameField.CharMat[next_x, next_y].HP = 0;
                checkIfDead(next_x, next_y);
                currCell.HP = currCell.FullHealth;
            }

            character.Coord = nextCell.Value;   //aggiornamento coordinate

            GameField.CharMat[curr_x, curr_y] = null;   //rimozione e spostamento nella matrice
            GameField.CharMat[next_x, next_y] = character;


            picBoxMat[curr_x, curr_y].Image = null;        //aggiornamento immagini
            picBoxMat[next_x, next_y].Image = character.Img;

            GameField.CharMat[next_x, next_y].HP -= 10;     //rimuovo punti vita

            checkIfDead(next_x, next_y);    //controllo se il personaggio � morto
        }

        private void gameLoop()     //muove ciclicamente ogni personaggio, con 0,3 secondi tra una mossa e l'altra
        {
            int i = 0;
            while (GameRunning)
            {
                if (i >= GameField.CharList.Count) { i = 0; }
                MoveCharacter(GameField.CharList[i]);
                i++;
                Thread.Sleep(300);
            }
            return;
        }

        public void startGame()     //avvia il gioco inizializzando il campo di gioco, caricando immagini e facendo partire il thread del gioco
        {
            if (WinnerPopup != null && WinnerPopup.Visible)
            {
                return;
            }
            GameField = new CField();
            LoadImages();
            GameRunning = true;
            GameThread = new Thread(new ThreadStart(() => gameLoop()));
            GameThread.IsBackground = true;
            GameThread.Start();
        }

        private void startButtonClick (object sender, EventArgs e)      //avvia il gioco
        {
            if(!GameRunning) startGame();
            return;
        }

        private void restartButtonClick(object sender, EventArgs e)     //riavvia il gioco
        {
            if (GameRunning)    //funziona solo se il gioco sta gi� runnando
            {
                GameRunning = false;
                if (GameThread != null && GameThread.IsAlive)   //chiude il thread
                {
                    GameThread.Join();
                }
                startGame();
            }
            return;
        }


        private void stopButtonClick(object sender, EventArgs e)    //ferma il gioco
        {
            GameRunning = false;
            ClearImages();
            if (GameThread != null && GameThread.IsAlive)   //chiude il thread
            {
                GameThread.Join();
            }
            return;
        }

    }
}