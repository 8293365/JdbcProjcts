﻿namespace crestale_gioco_vita
{
    partial class WinnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SuspendLayout();

            // WinnerForm
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "WinnerForm";
            Text = "Vincitore";
            MinimumSize = MaximumSize = Size = ClientSize = new Size(400, 400);
            ControlBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;

            winnerPicBox = new PictureBox
            {
                BackColor = Color.Black,
                Size = new Size(200, 200),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point((ClientSize.Width - 200) / 2, (ClientSize.Height - 200) / 2),
            };

            winnerText = new Label
            {
                Size = new Size(300, 40),
                Location = new Point((ClientSize.Width) / 2 -150, (ClientSize.Height - 200) / 2 - 50),
                Text = "IL VINCITORE È:",
                ForeColor = Color.Black,
                Font = new Font("Arial", 20, FontStyle.Bold),
                TabStop = false,
                TextAlign = ContentAlignment.MiddleCenter
            };

            confirmButton = new Button
            {
                Size = new Size(75, 30),
                Location = new Point((ClientSize.Width) / 2 - (75/2), (ClientSize.Height) / 2 + 125),
                Text = "OK",
                TextAlign = ContentAlignment.MiddleCenter,
                DialogResult = DialogResult.OK
            };

            Controls.Add(winnerPicBox);
            Controls.Add(winnerText);
            Controls.Add(confirmButton);

            ResumeLayout(false);
        }
        public PictureBox winnerPicBox;
        private Label winnerText;
        private Button confirmButton;
        #endregion
    }
}