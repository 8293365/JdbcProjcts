﻿using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace crestale_gioco_vita
{
    public partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        private void MainFormInitialize(int TLP_SIZE)
        {
            (int x, int y) form_size = (700, 775);
            tableLayoutPanel1 = new TableLayoutPanel();
            picBoxMat = new PictureBox[TLP_SIZE, TLP_SIZE];

            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();

            Panel spacerPanel = new Panel();
            spacerPanel.Size = new Size(form_size.x, 75);
            spacerPanel.Dock = DockStyle.Top;

            startButton = new Button();
            startButton.Location = new Point(0, 0);
            startButton.Size = new Size(75, 75);
            startButton.BackgroundImage = Properties.Resources.start;
            startButton.BackgroundImageLayout = ImageLayout.Zoom;
            startButton.Click += startButtonClick;

            restartButton = new Button();
            restartButton.Location = new Point((form_size.x / 2)-50, 0);
            restartButton.Size = new Size(75, 75);
            restartButton.BackgroundImage = Properties.Resources.restart;
            restartButton.BackgroundImageLayout = ImageLayout.Zoom;
            restartButton.Click += restartButtonClick;

            stopButton = new Button();
            stopButton.Location = new Point(form_size.x-95, 0);
            stopButton.Size = new Size(75, 75);
            stopButton.BackgroundImage = Properties.Resources.stop;
            stopButton.BackgroundImageLayout = ImageLayout.Zoom;
            stopButton.Click += stopButtonClick;

            spacerPanel.Controls.Add(startButton);
            spacerPanel.Controls.Add(restartButton);
            spacerPanel.Controls.Add(stopButton);

            // tableLayoutPanel1
            tableLayoutPanel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            tableLayoutPanel1.ColumnCount = TLP_SIZE;
            tableLayoutPanel1.RowCount = TLP_SIZE;

            for (int i = 0; i < TLP_SIZE; i++)      //genero le colonne e le righe della tablelayoutpanel
            {
                tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / TLP_SIZE));
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / TLP_SIZE));
            }

            int counter = 1;
            for (int i = 0; i < TLP_SIZE; i++)      //inserisco le picture box
            {
                for (int j = 0; j < TLP_SIZE; j++)
                {
                    picBoxMat[i, j] = new PictureBox();
                    picBoxMat[i, j].Name = "PicBox" + counter.ToString();
                    picBoxMat[i, j].AutoSize = true;
                    picBoxMat[i, j].Dock = DockStyle.Fill;
                    picBoxMat[i, j].BackColor = Color.Black;
                    picBoxMat[i, j].TabStop = false;
                    picBoxMat[i, j].SizeMode = PictureBoxSizeMode.Zoom;

                    tableLayoutPanel1.Controls.Add(picBoxMat[i, j], i, j);
                    counter++;
                }
            }

            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.GrowStyle = TableLayoutPanelGrowStyle.FixedSize;
            tableLayoutPanel1.Name = "tableLayoutPanel1";

            // MainForm
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MinimumSize = MaximumSize = Size = ClientSize = new Size(form_size.x, form_size.y);
            MaximizeBox = false;
            Icon = Properties.Resources.icon;
            Controls.Add(tableLayoutPanel1);
            Controls.Add(spacerPanel); 
            Name = "MainForm";
            Text = "Gioco della vita";
            CenterToScreen();

            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }


        private void InitializeComponent()
        {
            SuspendLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private PictureBox[,] picBoxMat;
        private Button startButton, restartButton, stopButton;
    }
}