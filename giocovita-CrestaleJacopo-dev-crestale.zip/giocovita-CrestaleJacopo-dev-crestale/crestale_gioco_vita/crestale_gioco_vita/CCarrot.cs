namespace crestale_gioco_vita;
class CCarrot : CCharacter
{
    public override int Strength { get { return 0; } }
    public override Bitmap Img { get { return Properties.Resources.carrot; } }

    public CCarrot() : base() { }
    public CCarrot(int tx, int ty) : base(tx, ty) { }
    public override (int, int)? SearchMove()
    {
        return null;
    }
}