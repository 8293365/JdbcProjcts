namespace crestale_gioco_vita;
class CLion : CCharacter
{
    public override int Strength { get { return 3; } }
    public override Bitmap Img { get { return Properties.Resources.lion; } }
    public CLion() : base() { }
    public CLion(int tx, int ty) : base(tx, ty) { }

    public override (int, int)? SearchMove()
    {
        Random rnd = new Random();
        List<(int, int)> emptyCells = new List<(int, int)>();   //celle vuote 
        List<(int, int)> preyCells = new List<(int, int)>();    //celle dove mangiare

        int tempx, tempy;
        CCharacter currCell;

        for (int i = -1; i < 2; i++)
        {
            tempy = ChangeCoord(this.Coord.y, i);
            for (int j = -1; j < 2; j++)
            {
                tempx = ChangeCoord(this.Coord.x, j);
                currCell = MainForm.GameField.CharMat[tempx, tempy];

                if (currCell == null) emptyCells.Add((tempx, tempy));

                else if (currCell.Strength == this.Strength - 1) preyCells.Add((tempx, tempy));
            }
        }
        if (preyCells.Count > 0) return preyCells[rnd.Next(0, preyCells.Count)];

        if (emptyCells.Count > 0) return emptyCells[rnd.Next(0, emptyCells.Count)];

        return null;
    }
}