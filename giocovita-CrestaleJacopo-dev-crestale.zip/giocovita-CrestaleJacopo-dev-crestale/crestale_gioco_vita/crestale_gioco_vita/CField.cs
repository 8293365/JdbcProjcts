using crestale_gioco_vita;
using System.ComponentModel;

public class CField
{
    public static int SIZE = 8;     //dimensioni campo, NB se vengono cambiate vengono cambiate anche nell'interfaccia grafica
    public CCharacter[,] CharMat;       //matrice personaggi
    public List<CCharacter> CharList = new List<CCharacter>();  //lista personaggi, serve per l'ordine delle mosse
    
    public CField(bool empty = false)
    {
        CharMat = new CCharacter[SIZE, SIZE];
        int i = 0;
        Random rnd = new Random();
        if (empty) return;
        int tempx, tempy;
        int maxChar = rnd.Next(SIZE * SIZE / 2, SIZE * SIZE * 3 / 4);   //riempio da met� a tre quarti delle celle
        while (i < maxChar)
        {
            tempx = rnd.Next(0, SIZE);
            tempy = rnd.Next(0, SIZE);
            if (CharMat[tempx, tempy] == null)
            {
                CharMat[tempx, tempy] = CCharacterFactory.GetRndCharacter(tempx, tempy);
                CharList.Add(CharMat[tempx, tempy]);
                i++;
            }
        }
        return;
    }
}