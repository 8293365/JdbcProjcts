using crestale_gioco_vita;
using System.CodeDom.Compiler;

public abstract class CCharacter
{
    public const int MAX_HEALTH = 100;
    public static Random Rnd = new Random();

    public abstract int Strength { get; }   //per capire chi pu� mangiare chi
    public abstract Bitmap Img { get; }

    public (int x, int y) Coord;

    public int FullHealth { get; set; }
    public int HP { get; set; }     //salute attuale

    public CCharacter()
    {
        FullHealth = HP = Rnd.Next(25, MAX_HEALTH);
    }

    public CCharacter(int tx, int ty)
    {
        Coord.x = tx;
        Coord.y = ty;
        FullHealth = HP = Rnd.Next(25, MAX_HEALTH);
    }

    public int ChangeCoord(int n1, int n2)  //somma le coordinate e applica l'effetto pacman
    {
        int tempSize = CField.SIZE;
        return Math.Abs((n1 + n2 + tempSize)) % tempSize;
    }

    abstract public (int, int)? SearchMove();   //cerca la mossa

}