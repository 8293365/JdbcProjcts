Scrivere un Programma in c# che preveda una Matrice grafica in una form;

Essa viene occupata da degli oggetti della classe  CPersonaggio che hanno un attributo comune Vita (che viene Generata Casualmente alla creazione del personaggio).

Premessa: i personaggi si cacciano tra loro nell' ordine indicato di seguito.

Leoni che fanno un movimento nella matrice di 1 posizione in qualsiasi direzione e mangiano le Volpi;
Volpi che fanno un movimento nella matrice di 1 posizione solo in verticale o in orizzontale e mangiano Conigli;
Conigli che fanno un movimento nella matrice di 1 posizione (in qualunque direzione ma mai uguale a quello fatto il turno prima) e mangiano Carote;
Le Carote, rimangono ferme ma invecchiano anche loro fino a scomparire dal campo da gioco.

I personaggi, quando si  spostano, possono andare su una casella libera oppure su una casella occupata da un personaggio che possono mangiare. Dopo essersi nutriti, la loro vita tornerà al valore massimo iniziale. I personaggi possono generare un evento che indica che sono morti per esaurimento della loro vita e anche altri eventi a tua discrezione (es. "mi sto indebolendo..."). Se i personaggi si spostano senza mangiare perdono un po' di vita. Può capitare che un personaggio non possa muoversi perchè circondato da personaggi che non può mangiare, in questo caso resterà fermo e non perderà vita.

Il programma che simula il tutto farà fare a turno una mossa a ciascun personaggio fino a quando non ne rimarrà uno soltanto che risulterà essere il vincitore.

Inserisci un bottone di start per far partire la simulazione e gestisci a piacere l'interfaccia. All'inizio, nel campo da gioco, deve esserci almeno una cella libera.